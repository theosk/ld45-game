---------------------------------------------------------------------
 IDraw ver 3.32.01

 Copyright ( c ) 1996 - 2001, hawk All Rights Reserved.

 2001 / 11 / 24.
---------------------------------------------------------------------

* change point *

 o necessity system became 65,536 color mores than ( 16 Bit colours ).
 Though I can be started even an environment of two hundred and fifty-six colors, I become color and am injured and occur.

 With o cartoon window, I tried to be able to do _Z_[_u with a road of a set up.
 An extension child of a set up file is ias.
 A drug & coughdrop to a cartoon window also is made with an explorer of ias file.
 If there is ias file for a time to open a picture file similar place, I open that.

 0 o'clock, the smallest price mended a bug not displayed for the smallest price with o numerical value input dialog.


* summary *

 It is a tool to draw o two hundred and fifty-six dot pictures less than a color.
 o detailed usage is idraw 3.  Please look at hlp.
 o freedom it is soft.
 I prohibit o reproduction, re-distribution.
 idraw of o UNIX is an other object.


* necessity system *

 OS : Japanese Microsoft Windows 95.
 Display color : 65,536 color mores than ( 16 Bit colours ).
 CPU : around-90-MHz Pentium.
 Memory : around thirty-two megabytes.
 Resolution : I have made 800 x 600 for a presupposition.

 Capacity is necessary as becoming vacant for a harddisk with no ten minutes.
 Windows 98, WindowsNT, action confirmation with Windows 2000 doesn't do.


* installation method *

 It makes an exclusive folder and defrosts to there.


* file explanation *

 IDraw 3.  exe.......... main part IDraw 3.  hlp.......... help ( Ver 3.32 businesses )
 IDraw 3.  Pal 16 that mem.......... character input window uses.  bmp........... standard sixteen color palette Readme.txt.......... this files, exceedingly


Bug * that understands * 

 If there is a similar color for o palette, a various inconvenience keeps it.


* contact * formerly

 E-MAIL : hawk@tam.ne.jp

 HomePage : http://www.tam.ne.jp/hawk/


 history *

 I tried to be able to preserve it for a file with 3.21 o two hundred and fifty-six color icons.
 I support a reading and a writing of 3.22 o PNG file.
 o file dialog memorized a display position and tried to have a height changed.
 I mended a bug of an edge drawing that occurs with 3.23 o 3.22.
 With 3.24 o file dialog, I mended OK bug that gets as with the file name if I move with a file famous state using a place button of a file.
 I a little changed o expansion reduction dialog.
 With one ~ 3.25 o cartoon window four-times I tried to be able to display it.
 I display it of a preservation dialog as an icon, slowly with o 3.21 and get high-speed.
 o trout eye ( large ) respectively tried to be able to set up a height with a width.
 I attached 3.26 o shifting movement function.
 A dotted line where 3.27 o selection range rotates for the surroundings mended a bug not displayed.
 I make it of 3.28 o AVI file.
 I attached a sub-_E_B_h_E for o shifting movement use.
 With one ~ o position window four-times I tried to be able to display it.
 I attached an option to try not closing a context menu even though I separate the right button of o mouse.
 I was funny and mended '� bug if I change a palette RGB during o cartoon selection.
 When preserving it as 3.29 o icon, though color two got transparent up to now, with a version, an option to make a color of the left lower _s_N_Z_< transparent adhered to it now.
 Transparent color " I can set up it. when preserving it as set up - " icon 
 Time to copy it to a clipboard as an icon also uses this option.
 With the intention that I mended a various bug that occurs when preserving it as o icon.
 I attached " Overwrite I come, confirm it " option for o file preservation dialog.
 I write upward that I remove a check, appear for a confirmation dialog, and get with no.
 I fitted to o editing menu there became not to be an item in relation a shifting movement.
 I was able to transport a shifting using a short cut and get with no.
 As I reformed the inside part of o cartoon window, whether there is a new bug related to that or not also isn't done.
 Irrespective of 3.30 o trout eye small display state, I tried to be able to display it for trout eye large.
 I tried to be able to display a context menu that appears with the right click around o range selection tool use with a keyboard.
 Set up - keyboard please assign a key to " display of a context menu " of a page " Short cuts ".
 With a preservation dialog, I mended a bug that there is time to become an error when I selected an icon as o icon.
 I mended a bug when preserving it with AVI with 3.31 o cartoon window.

-------------------------------------------------------------